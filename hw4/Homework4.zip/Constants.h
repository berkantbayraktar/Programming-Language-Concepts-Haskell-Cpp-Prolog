#ifndef HW4_CONSTANTS_H
#define HW+_CONSTANTS_H

enum Team{
	BARBARIANS,
	KNIGHTS
};

enum Goal{
	ATTACK,
	HEAL,
	TO_ALLY,
	TO_ENEMY,
	CHEST
};


#endif
